
outFile="typeOfTests.txt"

touch $outFile;
rm $outFile;
touch $outFile;

writeDumbTypeOfSuccessTest() {
	echo "      val e:Expr = parse(\"1\")" >> $outFile;
	echo "      val tExpected:Typ = TUndefined" >> $outFile;
	echo "      assertResult(tExpected) { " >> $outFile;
	echo "         typeof(empty, e)" >> $outFile;
	echo "      }" >> $outFile;
}

writeDumbTypeOfFailureTest() {
	echo "      // not sure how to capture this test" >> $outFile;
}

writeDumbTypeOfInductiveTest() {
	echo "      val e:Expr = parse(\"1 + 2\")" >> $outFile;
	echo "      val tExpected:Typ = TUndefined" >> $outFile;
	echo "      assertResult(tExpected) { " >> $outFile;
	echo "         typeof(empty, e)" >> $outFile;
	echo "      }" >> $outFile;
}

writeTypeOfTest() {
	echo "   \"$1\" should \"succeed in base case\" in {" >> $outFile;
	writeDumbTypeOfSuccessTest;
	echo "   }" >> $outFile;
	echo "   it should \"fail in base case\" in {" >> $outFile;
	writeDumbTypeOfFailureTest;
	echo "   }" >> $outFile;
	echo "   it should \"also succeed in inductive cases\" in {" >> $outFile;
	writeDumbTypeOfInductiveTest;
	echo "   }" >> $outFile;
}

echo "" >> $outFile;
echo "" >> $outFile;
echo "// BEGIN typeOf tests" >> $outFile;
echo "class Lab4TypeOfSpec(lab4: Lab4Like) extends FlatSpec {" >> $outFile;
echo "  import lab4._" >> $outFile;
echo "  import jsy.lab4.Parser.parse" >> $outFile;
while read -r line
do
	writeTypeOfTest "$line"
done < "typeOfItems.txt"
echo "}" >> $outFile;
echo "" >> $outFile;
echo "class Lab4SpecTypeOfRunner extends Lab4TypeOfSpec(jsy.student.Lab4)" >> $outFile;
echo "" >> $outFile;
echo "" >> $outFile;


