
outFile="stepTests.txt"

touch $outFile;
rm $outFile;
touch $outFile;

writeDumbStepSuccessTest() {
	echo "      val e:Expr = parse(\"1\")" >> $outFile;
	echo "      val ep:Expr = parse(\"1\")" >> $outFile;
	echo "      assertResult(ep) { " >> $outFile;
	echo "         step(e)" >> $outFile;
	echo "      }" >> $outFile;
}

writeDumbStepInductiveTest() {
	echo "      val e:Expr = parse(\"1 + 2\")" >> $outFile;
	echo "      val ep:Expr = parse(\"1\")" >> $outFile;
	echo "      assertResult(ep) { " >> $outFile;
	echo "         step(e)" >> $outFile;
	echo "      }" >> $outFile;
}

writeTypeOfTest() {
	echo "   \"$1\" should \"succeed in base case\" in {" >> $outFile;
	writeDumbStepSuccessTest;
	echo "   }" >> $outFile;
	echo "   it should \"also succeed in inductive cases\" in {" >> $outFile;
	writeDumbStepInductiveTest;
	echo "   }" >> $outFile;
}

echo "" >> $outFile;
echo "" >> $outFile;
echo "// BEGIN step tests" >> $outFile;
echo "class Lab4StepSpec(lab4: Lab4Like) extends FlatSpec {" >> $outFile;
echo "  import lab4._" >> $outFile;
echo "  import jsy.lab4.Parser.parse" >> $outFile;
while read -r line
do
	writeTypeOfTest "$line"
done < "stepItems.txt"
echo "}" >> $outFile;
echo "" >> $outFile;
echo "class Lab4SpecStepRunner extends Lab4StepSpec(jsy.student.Lab4)" >> $outFile;
echo "" >> $outFile;
echo "" >> $outFile;


