
touch out.txt
rm out.txt
touch out.txt

cat fullPref.txt >> out.txt

./createNewTests.sh

cat newTests.txt >> out.txt

cat fullSuf.txt >> out.txt

