used to create a test file with lots of test blocks
exctute runMe.sh
./runMe.sh

this will create out.txt... a file with all the original lab tests + additional tests. the additional tests are in their own runners AND they are integrated into the test file.

play around with this as you see fit.
