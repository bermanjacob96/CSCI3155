
touch newTests.txt
rm newTests.txt
touch newTests.txt

./createTypeOfTests.sh
cat typeOfTests.txt >> newTests.txt

./createStepTests.sh
cat stepTests.txt >> newTests.txt


